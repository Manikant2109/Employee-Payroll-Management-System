﻿Imports System.Data.SqlClient

Public Class Form16
    Dim cn As SqlConnection
    Dim cmd, cmd1, cmd2, cmd3, cmd4 As New SqlCommand

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        cmd4 = New SqlCommand("select * from PAYROLL where FROM_DATE= convert(date,'" & DateTimePicker1.Value & "',103) and TO_DATE= convert(date,'" & DateTimePicker2.Value & "',103) and EMPLOYEE_CODE='" & ComboBox2.Text & "'", cn)
        dr3 = cmd4.ExecuteReader
        If dr3.Read Then
            Button1.Visible = False
            Button2.Visible = False
            Button3.Visible = False
            Me.FormBorderStyle = FormBorderStyle.None
            Dim preview As New PrintPreviewDialog
            Dim pd As New System.Drawing.Printing.PrintDocument
            pd.DefaultPageSettings.Landscape = True
            AddHandler pd.PrintPage, AddressOf onprintpage
            preview.Document = pd
            preview.ShowDialog()
            Button1.Visible = True
            Button2.Visible = True
            Button3.Visible = True
            Me.FormBorderStyle = FormBorderStyle.Sizable
        Else
            cmd3 = New SqlCommand("insert into PAYROLL ([EMPLOYEE_CODE],[EMPLOYEE_NAME],[FROM_DATE],[TO_DATE],[AMOUNT]) values ('" & ComboBox2.Text & "', '" & Label14.Text & "' , convert(date,'" & DateTimePicker1.Value & "',103), convert(date,'" & DateTimePicker2.Value & "',103), '" & Label22.Text & "') ", cn)
            cmd3.ExecuteNonQuery()
            Button1.Visible = False
            Button2.Visible = False
            Button3.Visible = False
            Me.FormBorderStyle = FormBorderStyle.None
            Dim preview As New PrintPreviewDialog
            Dim pd As New System.Drawing.Printing.PrintDocument
            pd.DefaultPageSettings.Landscape = True
            AddHandler pd.PrintPage, AddressOf onprintpage
            preview.Document = pd
            preview.ShowDialog()
            Button1.Visible = True
            Button2.Visible = True
            Button3.Visible = True
            Me.FormBorderStyle = FormBorderStyle.Sizable
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

    End Sub

    Dim da As SqlDataAdapter

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Dim dt As DataTable
    Dim dr, dr1, dr2, dr3 As SqlDataReader

    Private Sub Form16_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\manik\source\repos\WinFormsApp4\WinFormsApp4\Database1.mdf;Integrated Security=True;MultipleActiveResultSets=True")
        cn.Open()
        da = New SqlDataAdapter("select * from EMPLOYEE_DETAILS", cn)
        dt = New DataTable
        da.Fill(dt)
        'Insert the Default Item to DataTable.
        Dim row As DataRow = dt.NewRow()
        row(0) = 0
        dt.Rows.InsertAt(row, 0)
        'Assign DataTable as DataSource.
        ComboBox2.DataSource = dt
        ComboBox2.DisplayMember = "EMPLOYEE_CODE"
        ComboBox2.ValueMember = "EMPLOYEE_NAME"

    End Sub
    Private Sub onprintpage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)
        Using bmp As Bitmap = New Bitmap(Me.Width, Me.Height)
            Me.DrawToBitmap(bmp, New Rectangle(0, 0, Me.Width, Me.Height))
            Dim ratio As Single = CSng(bmp.Width / bmp.Height)
            If ratio > e.MarginBounds.Width / e.MarginBounds.Height Then
                e.Graphics.DrawImage(bmp, e.MarginBounds.Left, CInt(e.MarginBounds.Top + (e.MarginBounds.Height / 2) - ((e.MarginBounds.Width / ratio) / 2)), e.MarginBounds.Width, CInt(e.MarginBounds.Width / ratio))
            Else
                e.Graphics.DrawImage(bmp, CInt(e.MarginBounds.Left + (e.MarginBounds.Width / 2)) - (e.MarginBounds.Height * ratio / 2), e.MarginBounds.Top, CInt(e.MarginBounds.Height * ratio), e.MarginBounds.Height)
            End If
        End Using
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd1 = New SqlCommand("select * from EMPLOYEE_DETAILS where EMPLOYEE_CODE='" & ComboBox2.Text & "';", cn)
        dr = cmd1.ExecuteReader
        If dr.Read Then
            Label14.Text = dr(4).ToString
            Label18.Text = dr(2).ToString
            Label19.Text = dr(3).ToString
        Else
            MsgBox("Wrong Employee Code Entered .....!", MsgBoxStyle.Critical)
            Exit Sub
        End If
        Try
            cmd = New SqlCommand("select * from SALARY where EMPLOYEE_CODE='" & ComboBox2.Text & "';", cn)
            dr1 = cmd.ExecuteReader
            dr1.Read()
            Dim bp, epf, ta, dea, hra, sum As Integer
            bp = dr1(2).ToString
            epf = dr1(3).ToString
            ta = dr1(4).ToString
            dea = dr1(5).ToString
            hra = dr1(6).ToString
            cmd2 = New SqlCommand("select sum(WORKING_HOURS) from ATTENDANCE where EMPLOYEE_CODE = '" & ComboBox2.Text & "'and EDATE between convert(date,'" & DateTimePicker1.Value & "',103) and convert(date,'" & DateTimePicker2.Value & "',103);", cn)
            dr2 = cmd2.ExecuteReader
            dr2.Read()
            sum = dr2(0).ToString

            Label15.Text = sum * bp
            Label16.Text = (Val(Label15.Text) * epf) / 100
            Label17.Text = (Val(Label15.Text) * ta) / 100
            Label20.Text = (Val(Label15.Text) * dea) / 100
            Label21.Text = (Val(Label15.Text) * hra) / 100
            Label22.Text = Val(Label15.Text) + Val(Label17.Text) + Val(Label20.Text) + Val(Label21.Text) - Val(Label16.Text)
        Catch ex As Exception
            MsgBox("Enter Proper Dates ....!", MsgBoxStyle.Critical)
        End Try
    End Sub
End Class