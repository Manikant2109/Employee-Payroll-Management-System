﻿Imports System.Data.SqlClient
Public Class Form12
    Dim cn As SqlConnection
    Dim cmd, cmd1, cmd2, cmd3, cmd4 As New SqlCommand
    Dim da As SqlDataAdapter
    Dim dt As DataTable
    Dim dr, dr1, dr2, dr3 As SqlDataReader

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form17.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim entry_hour, entry_minute As Integer
        Dim ent, ext, duration As Double
        If Label2.Text = "Entry Time :" Then
            cmd4 = New SqlCommand("insert into ATTENDANCE ([EMPLOYEE_CODE],[EMPLOYEE_NAME],[EDATE],[ENTRY_HOUR],[ENTRY_MINUTE]) values ('" & ComboBox1.Text & "','" & Label6.Text & "', convert(date,'" & DateTimePicker1.Value & "',103),'" & ComboBox2.Text & "','" & ComboBox3.Text & "')", cn)
            cmd4.ExecuteNonQuery()
            MsgBox("Saved Successfully", MsgBoxStyle.Information)
            Me.Close()
        End If
        If Label2.Text = "Exit Time :" Then
            cmd1 = New SqlCommand("select ENTRY_HOUR, ENTRY_MINUTE from ATTENDANCE where EDATE = convert(date,'" & DateTimePicker1.Value & "',103) and EMPLOYEE_CODE='" & ComboBox1.Text & "'", cn)
            dr1 = cmd1.ExecuteReader
            dr1.Read()
            entry_hour = dr1("ENTRY_HOUR")
            entry_minute = dr1("ENTRY_MINUTE")
            ent = Val(ComboBox2.Text) - entry_hour
            ext = (Val(ComboBox3.Text) - entry_minute) / 60
            duration = ent + ext
            Label6.Text = duration
            cmd3 = New SqlCommand("update ATTENDANCE set WORKING_HOURS ='" & duration & "', EXIT_HOUR ='" & ComboBox2.Text & "', EXIT_MINUTE ='" & ComboBox3.Text & "' where EDATE = convert(date,'" & DateTimePicker1.Value & "',103) and EMPLOYEE_CODE ='" & ComboBox1.Text & "'", cn)
            cmd3.ExecuteNonQuery()
            MsgBox("Saved Successfully", MsgBoxStyle.Information)
            Me.Close()
        End If
    End Sub



    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        cmd = New SqlCommand("select * from EMPLOYEE_DETAILS where EMPLOYEE_CODE='" & ComboBox1.Text & "';", cn)
        dr = cmd.ExecuteReader
        If dr.Read() Then
            Label6.Text = dr(4).ToString
        Else
            MsgBox("Select Employee Code first ....!", MsgBoxStyle.Critical)
            Exit Sub
        End If
        cmd2 = New SqlCommand("select ENTRY_HOUR, ENTRY_MINUTE from ATTENDANCE where EDATE = convert(date,'" & DateTimePicker1.Text & "',103) and EMPLOYEE_CODE='" & ComboBox1.Text & "';", cn)
        dr3 = cmd2.ExecuteReader
        dr3.Read()
        cmd4 = New SqlCommand("select WORKING_HOURS  from ATTENDANCE where EDATE = convert(date,'" & DateTimePicker1.Text & "',103) and EMPLOYEE_CODE='" & ComboBox1.Text & "';", cn)
        dr2 = cmd4.ExecuteReader
        dr2.Read()
        If dr3.HasRows = True Then
            If IsDBNull(dr2("WORKING_HOURS")) Then
                MsgBox("Continue to save exit time ....!", MsgBoxStyle.Information)
                ComboBox3.Enabled = True
                ComboBox2.Enabled = True
                Button1.Enabled = True
                Label2.Text = "Exit Time :"
            Else
                MsgBox("Attendance already taken ....!", MsgBoxStyle.Information)
                ComboBox3.Enabled = False
                ComboBox2.Enabled = False
                Button1.Enabled = False
                DateTimePicker1.Enabled = False
            End If
        Else
            MsgBox("Continue to save entry time ....!", MsgBoxStyle.Information)
            ComboBox3.Enabled = True
            ComboBox2.Enabled = True
            Button1.Enabled = True
            DateTimePicker1.Enabled = True
        End If
    End Sub

    Private Sub Form12_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox3.Enabled = False
        ComboBox2.Enabled = False
        Button1.Enabled = False
        DateTimePicker1.Enabled = False
        cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\manik\source\repos\WinFormsApp4\WinFormsApp4\Database1.mdf;Integrated Security=True;MultipleActiveResultSets=True")
        cn.Open()
        da = New SqlDataAdapter("select EMPLOYEE_CODE,EMPLOYEE_NAME from EMPLOYEE_DETAILS", cn)
        dt = New DataTable
        da.Fill(dt)
        'Insert the Default Item to DataTable.
        Dim row As DataRow = dt.NewRow()
        row(0) = 0
        row(1) = "Please select"
        dt.Rows.InsertAt(row, 0)
        'Assign DataTable as DataSource.
        ComboBox1.DataSource = dt
        ComboBox1.DisplayMember = "EMPLOYEE_CODE"
        ComboBox1.ValueMember = "EMPLOYEE_NAME"
    End Sub
End Class