﻿Imports System.Data.SqlClient
Public Class Form18
    Dim cn As SqlConnection
    Dim cmd As SqlCommand
    Dim dr As SqlDataReader
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New SqlCommand("select * from ADMINISTRATOR where ADMINID ='" & TextBox1.Text & "';", cn)
        dr = cmd.ExecuteReader
        If dr.Read Then
            Label4.Text = dr(1).ToString
            Label5.Text = dr(2).ToString
        Else
            MsgBox("Wrong Adminid Entered .....!", MsgBoxStyle.Critical)
            TextBox1.Clear()
        End If
    End Sub

    Private Sub Form18_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\manik\source\repos\WinFormsApp4\WinFormsApp4\Database1.mdf;Integrated Security=True;MultipleActiveResultSets=True")
        cn.Open()
    End Sub
End Class