﻿Imports System.Data.SqlClient
Public Class Form10
    Dim cn As SqlConnection
    Dim cmd As New SqlCommand
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Form10_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\manik\source\repos\WinFormsApp4\WinFormsApp4\Database1.mdf;Integrated Security=True;MultipleActiveResultSets=True")
        cn.Open()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New SqlCommand("insert into DEPARTMENT_DETAILS([DEPARTMENT_CODE], [DEPARTMENT_NAME]) values ('" & TextBox1.Text & "','" & TextBox2.Text & "')", cn)
        cmd.ExecuteNonQuery()
        MsgBox("Saved successfully ....!", MsgBoxStyle.Information)
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub
End Class