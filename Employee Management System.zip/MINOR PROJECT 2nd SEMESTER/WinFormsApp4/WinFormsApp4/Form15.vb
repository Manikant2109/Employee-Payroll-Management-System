﻿Imports System.Data.SqlClient
Public Class Form15
    Dim cn As SqlConnection
    Dim cmd, cmd1, cmd2, cmd3, cmd4, cmd5 As New SqlCommand
    Dim da As SqlDataAdapter
    Dim dt As DataTable
    Dim dr As SqlDataReader

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd1 = New SqlCommand("select * from EMPLOYEE_DETAILS where EMPLOYEE_CODE='" & ComboBox1.Text & "';", cn)
        dr = cmd1.ExecuteReader
        If dr.Read Then
            Label3.Text = dr(4).ToString
            ComboBox2.Enabled = True
            ComboBox3.Enabled = True
            ComboBox4.Enabled = True
            ComboBox5.Enabled = True
            ComboBox6.Enabled = True
        Else
            MsgBox("Wrong Employee Code Entered .....!", MsgBoxStyle.Critical)
            ComboBox2.Enabled = False
            ComboBox3.Enabled = False
            ComboBox4.Enabled = False
            ComboBox5.Enabled = False
            ComboBox6.Enabled = False
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        cmd = New SqlCommand("update SALARY set BASIC_PAY_PER_HOUR = '" & ComboBox2.Text & "' where EMPLOYEE_CODE = '" & ComboBox1.Text & "'", cn)
        cmd.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        cmd2 = New SqlCommand("update SALARY set EPF = '" & ComboBox3.Text & "' where EMPLOYEE_CODE = '" & ComboBox1.Text & "'", cn)
        cmd2.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        cmd3 = New SqlCommand("update SALARY set DA = '" & ComboBox4.Text & "' where EMPLOYEE_CODE = '" & ComboBox1.Text & "'", cn)
        cmd3.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        cmd4 = New SqlCommand("update SALARY set TA = '" & ComboBox5.Text & "' where EMPLOYEE_CODE = '" & ComboBox1.Text & "'", cn)
        cmd4.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        cmd5 = New SqlCommand("update SALARY set HRA = '" & ComboBox6.Text & "' where EMPLOYEE_CODE = '" & ComboBox1.Text & "'", cn)
        cmd5.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Form15_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox2.Enabled = False
        ComboBox3.Enabled = False
        ComboBox4.Enabled = False
        ComboBox5.Enabled = False
        ComboBox6.Enabled = False
        cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\manik\source\repos\WinFormsApp4\WinFormsApp4\Database1.mdf;Integrated Security=True;MultipleActiveResultSets=True")
        cn.Open()
        da = New SqlDataAdapter("select * from EMPLOYEE_DETAILS", cn)
        dt = New DataTable
        da.Fill(dt)
        'Insert the Default Item to DataTable.
        Dim row As DataRow = dt.NewRow()
        row(0) = 0
        dt.Rows.InsertAt(row, 0)
        'Assign DataTable as DataSource.
        ComboBox1.DataSource = dt
        ComboBox1.DisplayMember = "EMPLOYEE_CODE"
        ComboBox1.ValueMember = "EMPLOYEE_NAME"
    End Sub
End Class