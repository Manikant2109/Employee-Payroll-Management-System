﻿Imports System.Data.SqlClient
Public Class Form8
    Dim cn As SqlConnection
    Dim cmd As New SqlCommand
    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\manik\source\repos\WinFormsApp4\WinFormsApp4\Database1.mdf;Integrated Security=True;MultipleActiveResultSets=True")
        cn.Open()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New SqlCommand("delete from EMPLOYEE_DETAILS where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd.ExecuteNonQuery()
        MsgBox("Deleted Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class