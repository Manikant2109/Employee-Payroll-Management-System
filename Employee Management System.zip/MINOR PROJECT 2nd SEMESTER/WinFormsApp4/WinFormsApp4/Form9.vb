﻿Imports System.Data.SqlClient
Public Class Form9
    Dim cn As SqlConnection
    Dim cmd, cmd1, cmd2, cmd3, cmd4, cmd5, cmd6, cmd7, cmd8, cmd9, cmd10, cmd11 As New SqlCommand

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        cmd2 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_NAME = '" & TextBox2.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd2.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        cmd3 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_DOB = convert(date,'" & DateTimePicker1.Value & "',103) where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd3.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        cmd4 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_MOB_NO = '" & TextBox2.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd4.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        cmd5 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_ADDRESS = '" & TextBox2.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd5.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        cmd9 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_BLOOD_GROUP = '" & ComboBox4.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd9.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        cmd10 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_PF_AC_NO = '" & TextBox4.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd10.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        cmd11 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_BANK_AC_NO = '" & TextBox7.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd11.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        cmd9 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_GENDER = '" & ComboBox5.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd9.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        cmd6 = New SqlCommand("update EMPLOYEE_DETAILS set DEPARTMENT_CODE = '" & ComboBox1.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd6.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        cmd7 = New SqlCommand("update EMPLOYEE_DETAILS set DEPARTMENT_NAME = '" & ComboBox2.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd7.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        cmd8 = New SqlCommand("update EMPLOYEE_DETAILS set DESIGNATION = '" & ComboBox3.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd8.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub

    Dim da As SqlDataAdapter
    Dim dt As DataTable
    Dim dt1 As DataTable
    Dim dr As SqlDataReader
    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        TextBox6.Enabled = False
        TextBox7.Enabled = False
        ComboBox1.Enabled = False
        ComboBox2.Enabled = False
        ComboBox3.Enabled = False
        ComboBox4.Enabled = False
        ComboBox5.Enabled = False
        cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\manik\source\repos\WinFormsApp4\WinFormsApp4\Database1.mdf;Integrated Security=True;MultipleActiveResultSets=True")
        cn.Open()
        da = New SqlDataAdapter("select * from DEPARTMENT_DETAILS", cn)
        dt = New DataTable
        dt1 = New DataTable
        da.Fill(dt)
        'Insert the Default Item to DataTable.
        Dim row As DataRow = dt.NewRow()
        row(0) = 0
        row(1) = "Please select"
        dt.Rows.InsertAt(row, 0)
        'Assign DataTable as DataSource.
        ComboBox1.DataSource = dt
        ComboBox1.DisplayMember = "DEPARTMENT_CODE"
        ComboBox1.ValueMember = "DEPARTMENT_NAME"
        da.Fill(dt1)
        'Insert the Default Item to DataTable.
        Dim row1 As DataRow = dt1.NewRow()
        row1(0) = 0
        row1(1) = "Please select"
        dt1.Rows.InsertAt(row1, 0)
        'Assign DataTable as DataSource.
        ComboBox2.DataSource = dt1
        ComboBox2.DisplayMember = "DEPARTMENT_NAME"
        ComboBox2.ValueMember = "DEPARTMENT_CODE"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cmd = New SqlCommand("select * from EMPLOYEE_DETAILS where EMPLOYEE_CODE='" & TextBox1.Text & "';", cn)
        dr = cmd.ExecuteReader
        If dr.Read Then
            TextBox2.Enabled = True
            TextBox3.Enabled = True
            TextBox4.Enabled = True
            TextBox5.Enabled = True
            TextBox6.Enabled = True
            TextBox7.Enabled = True
            ComboBox1.Enabled = True
            ComboBox2.Enabled = True
            ComboBox3.Enabled = True
            ComboBox4.Enabled = True
            ComboBox5.Enabled = True
        Else
            MsgBox("Wrong Employee Code Entered .....!", MsgBoxStyle.Critical)
            TextBox1.Clear()
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            TextBox4.Enabled = False
            TextBox5.Enabled = False
            TextBox6.Enabled = False
            TextBox7.Enabled = False
            ComboBox1.Enabled = False
            ComboBox2.Enabled = False
            ComboBox3.Enabled = False
            ComboBox4.Enabled = False
            ComboBox5.Enabled = False
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        cmd1 = New SqlCommand("update EMPLOYEE_DETAILS set EMPLOYEE_CODE = '" & TextBox2.Text & "' where EMPLOYEE_CODE = '" & TextBox1.Text & "'", cn)
        cmd1.ExecuteNonQuery()
        MsgBox("Saved Successfully", MsgBoxStyle.Information)
    End Sub
End Class